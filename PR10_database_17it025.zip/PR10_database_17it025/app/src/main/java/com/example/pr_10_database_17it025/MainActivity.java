package com.example.pr_10_database_17it025;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText name,surname,marks;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb =new DatabaseHelper(this);
        name=(EditText)findViewById(R.id.editText);
        surname=(EditText)findViewById(R.id.editText2);
        marks=(EditText)findViewById(R.id.editText3);
        button=(Button)findViewById(R.id.button);
        AddData();
    }
    public void AddData(){
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDb.insertData(name.getText().toString(),surname.getText().toString(),marks.getText().toString());

                if (isInserted==true)
                    Toast.makeText(MainActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this,"Data not inserted",Toast.LENGTH_LONG).show();
            }
        });
    }

}
