package com.example.login_17it025;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView tv1,tv2,ans,tv3;
    private Button btn1,btn2;
    private EditText login;
    int counter= 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        ans = findViewById(R.id.ans);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        login = findViewById(R.id.et);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tv1.getText().toString().equals("jeel") && tv2.getText().toString().equals("1234"))
                {
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    ans.setVisibility(View.VISIBLE);
                    ans.setBackgroundColor(Color.GREEN);
                    ans.setText("Login successful");
                }
                else{
                    Toast.makeText(getApplicationContext(),"Wrong Credencials",Toast.LENGTH_SHORT).show();
                    ans.setVisibility(View.VISIBLE);
                    ans.setBackgroundColor(Color.RED);
                    counter=counter-1;
                    tv3.setText(Integer.toString(counter));
                    ans.setVisibility(View.VISIBLE);
                    ans.setBackgroundColor(Color.RED);
                    ans.setText("Login Unsuccessful");
                    if(counter==0 ){
                        btn1.setEnabled(false);
                        finish();
                    }
                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
